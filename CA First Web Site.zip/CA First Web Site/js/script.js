function myFunction(){
    document.getElementById("pag3").innerHTML = "Oh no!... Just scroll down the page and click in the: 'button inside de footer' and get the page back to the normal";
}

function myAnotherFunction(){
    document.getElementById("pag3").innerHTML = "See, everything is back to the normal";
}
